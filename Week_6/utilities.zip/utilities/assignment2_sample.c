#include <stdio.h>

int main()
{
	// this is a dummy function
	float sum = 0;
	// testing the sed commands
	
	int x = 6; // single-line comment
	x = x + 5;
	
	char y = 'n'; /* end of c 
	file */
}
