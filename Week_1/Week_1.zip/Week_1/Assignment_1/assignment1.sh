#!/bin/bash

#take the input of csv file name which is passed as an argument


#sort the csv file alphabetically based on first column data

