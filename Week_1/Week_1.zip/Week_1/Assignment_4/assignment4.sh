#!/bin/bash

#get the Cartesian x and y coodinates of a point that are passed as arguments


#convert the Cartesian coordinates to the corresponding polar coordinates
#compute radius and theta (in degrees) upto 5 decimal places
#note: theta should range from 0 to 360 degrees

