#!/bin/bash

#take the input file name which is passed as an argument

#find the valid IP addresses present in the input file

#print the valid IP addresses found

